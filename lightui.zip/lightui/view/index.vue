<template>
    <div class="wrapper">
        <div class="logo-wrap">
            <img src="../images/light.png" class="logo"/>
            <span class="logo-text">一个适用于Vue H5的金融 UI 组件库</span>
        </div>
        <div v-for="(data,index) in datas" :key="index" >
            <span class="title">{{data.title}}</span>
            <lc-cell 
                v-for="(d,i) in data.comp" :key="i" 
                @LcCellClicked="LcCellClicked(d.path,d.label)"
            >
                <div slot="title" class="cont-wrap">
                    <img class="icon" :src="d.icon" />
                    <span>{{d.label}}</span>
                </div>
            </lc-cell>
        </div>    
    </div>
</template>

<script>
    import Light from 'light';
    import datas from '../lib/DATA.js';
    
    export default {
        data: () => ({
            datas:datas
        }),
        methods: {
            LcCellClicked(src,title){
                Light.navigate(src, {}, {title: title,replace:false})
            }

        },
        mounted() {
            console.log(this.datas.comp)
        },
    };
</script>
<style scoped>
.logo-wrap{ display: flex; flex-direction: column; align-items: center; background-color: #fafafa; padding: 15px;}
.logo{ width: 60px; height: 60px;}
.logo-text{ color: #646464; font-size: 14px; text-align: center; margin-top: 10px;}
.title{display: flex; box-sizing: border-box; height: 38px; font-size: 16px; line-height: 38px; padding-left: 15px; font-weight: bold; background-color: #f2f2f2; color: #666;}
.icon{ width: 25px; height: 25px; margin:0 10px;}
.cont-wrap{ display: flex; align-items: center;}
</style>
