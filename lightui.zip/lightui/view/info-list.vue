<template>
  <div class="wrap">
      <lc-title title="信息列表"></lc-title>
      <category title="图文结合"></category>
      
      <lc-info-list 
        type="imgleft"
        :infoList="infoList"
        @infoClick="infoClick"
      ></lc-info-list>

      <lc-info-list 
        type="imgright"
        :infoList="infoList"
        :timeStyle='timeStyle'
        @infoClick="infoClick"
      ></lc-info-list>

      <category title="纯文本"></category>
      <lc-info-list 
        type="text"
        :infoList="infoList1"
        @infoClick="infoClick"
      ></lc-info-list>

      <lc-info-list 
        type="text"
        :line="2"
        :infoList="infoList1"
        @infoClick="infoClick"
      ></lc-info-list>
  </div>
</template>

<script>
import LcTitle from '_mods/title.vue';
import Category from '_mods/category.vue';
export default {
	components: { LcTitle, Category },
    data(){
      return {
        timeStyle:{textAlign:'left'},
        infoList:[
          {
              textTitle:'金点子提醒：京东开始全面升级到电子发票，让电子发票引领未来',
              textInfo:'今年以来，虽然A股上涨了6.1（截止发稿前），但是境外资金持续走弱但是境外资金持续走弱但是境外资金持续走弱',
              src:'../images/TB1jkA5g9_I8KJjy0FoXXaFnVXa-320-320.png',
              textTime:'2018-02-09'             
          }
        ],
        infoList1:[
          {
              textTitle:'金点子提醒：京东开始全面升级到电子发票，让电子发票引领未来金点子提醒：京东开始全面升级到电子发票，让电子发票引领未来',
              textTime:'2017-12-18 15:01:23',
              textInfo:'今年以来，虽然A股上涨了6.1（截止发稿前），但是境外资金持续走弱但是境外资金持续走弱但是境外资金持续走弱'              
          }
        ]       
      }
    },
    components: { LcTitle, Category},
    methods:{
      infoClick(index) {
        console.log("clicked" + index);
      }
    }
  }
</script>

<style scoped>
  .wrap{ background: #fff;}
</style>
