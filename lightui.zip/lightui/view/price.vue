<template>
  <div class="demo-list">
    <lc-title title="商品价格"></lc-title>
    <category title="基本用法"></category>
    <p>无人民币符号，有千位分隔</p>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-price :price="1010" :needSymbol="false" :thousands="true"/>
        </span>
      </lc-cell>
    </div>
    <p>带人民币符号，无千位分隔</p>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-price :price="10010.01" :needSymbol="true" :thousands="false"/>
        </span>
      </lc-cell>
    </div>
    <p>带人民币符号，有千位分隔，保留小数点后三位</p>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-price :price="15213.1221" :decimalDigits="3" :needSymbol="true" :thousands="true"/>
        </span>
      </lc-cell>
    </div>
  </div>
</template>

<script>
import LcTitle from '_mods/title.vue';
import Category from '_mods/category.vue';
export default {
	components: { LcTitle, Category },
};
</script>

<style lang="less" scoped>
.demo-con {
  padding-left: 20px;
  margin-bottom: 40px;
}
p{ line-height: 26px; padding:10px; font-size: 14px;}
</style>
