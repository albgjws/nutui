<template>
  <div class="demo-list">
    <lc-title title="公告栏"></lc-title>
    <category title="默认用法"></category>
    <lc-noticebar
      color="#000"
      background="#fff"
      delay="3"
      speed="2"
      text="华为畅享9新品即将上市，活动期间0元预约可参与抽奖，赢HUAWEI WATCH等好礼，更多产品信息请持续关注！"
    ></lc-noticebar>
    <category title="禁用滚动"></category>
    <lc-noticebar
      text="华为畅享9新品即将上市，活动期间0元预约可参与抽奖，赢HUAWEI WATCH等好礼，更多产品信息请持续关注！"
      :scrollable="false"
    ></lc-noticebar>
    <category title="通告栏模式--关闭模式"></category>
    <lc-noticebar
      :closeMode="true"
      @click="hello"
    >华为畅享9新品即将上市，活动期间0元预约可参与抽奖，赢HUAWEI WATCH等好礼，更多产品信息请持续关注！
    </lc-noticebar>
    <category title="通告栏模式--链接模式"></category>
    <lc-noticebar
      left-icon="https://img13.360buyimg.com/imagetools/jfs/t1/72082/2/3006/1197/5d130c8dE1c71bcd6/e48a3b60804c9775.png"
    >
      <a href="https://www.jd.com">京东商城</a>
    </lc-noticebar>
  </div>
</template>

<script>
import LcTitle from '_mods/title.vue';
import Category from '_mods/category.vue';
export default {
  components: { LcTitle, Category },
  methods: {
    hello() {
      console.log("hello world");
    }
  }
};
</script>

<style lang="less" scoped>
</style>
