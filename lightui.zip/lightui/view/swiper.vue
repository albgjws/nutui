<template>
    <div id="vueSwiper">
        <lc-title title="滑动切换"></lc-title>
        <category title="横向切换"></category>
        <lc-swiper
            :paginationVisibile="true"
            direction="horizontal"
            :swiperData="dataImgItem"
        >
           <div  v-for="(item,index) in dataImgItem" :key="index"  class="nut-swiper-slide ">
                <img :src="item.imgSrc"   style="width:100%; height:100%;"/> 
            </div>

        </lc-swiper>

        <category title="横向切换带指示器"></category>
        <lc-swiper
            :paginationVisibile="true"
            direction="horizontal"
            :swiperData="dataImgItem"
            :canDragging="false"
            :paginationVisible="true"
        >
             <div  v-for="(item,index) in dataImgItem" :key="index"  class="nut-swiper-slide ">
                <img :src="item.imgSrc"   style="width:100%; height:100%;" /> 
            </div>

        </lc-swiper>

         <category title="横向循环切换"></category>
         <lc-swiper
            :paginationVisibile="true"
            direction="horizontal"
            :swiperData="dataImgItem"
            :loop="true"
            :canDragging="false"
            :paginationVisible="true"
        >
             <div  v-for="(item,index) in dataImgItem" :key="index"  class="nut-swiper-slide ">
                <img :src="item.imgSrc"   style="width:100%; height:100%;" /> 
            </div>
        </lc-swiper>

         <category title="纵向自动播放"></category>
          <lc-swiper
            direction="vertical"
            :autoPlay="3000"
            :swiperData="dataImgItem"
        >
             <div  v-for="(item,index) in dataImgItem" :key="index"  class="nut-swiper-slide ">
                <img :src="item.imgSrc"   style="width:100%; height:100%;" /> 
            </div>
        </lc-swiper>

        <category title="滑动懒加载图片"></category>
        <lc-swiper
            direction="horizontal"
            :paginationClickable="true"
            :swiperData="dataImgItem"
            :lazyLoad="true"
             :paginationVisible="true"
             @slideChangeEnd="slideChangeEnd"
             @slideMove="slideMove"
             @slideChangeStart="slideChangeStart"
        >
             <div  v-for="(item,index) in dataImgItem" :key="index"  class="nut-swiper-slide ">
                <img :data-src="item.imgSrc"  style="width:100%; height:100%;" class="nut-img-lazyload"/> 
            </div>

        </lc-swiper>
    </div>

</template>
<script>
    import LcTitle from '_mods/title.vue';
    import Category from '_mods/category.vue';
    export default {
    components: { LcTitle, Category },
        data(){
            return{
                dataItem:[],
                dataImgItem:[],
            }
        },
        mounted(){
            setTimeout(()=>{
                this.dataItem = [{
                    name:1
                },{
                    name:2
                },{
                    name:3
                },{
                    name:4
                }]

                this.dataImgItem = [
                    {
                        imgSrc:'../images/banner1.jpg'
                    },
                    {
                        imgSrc:'../images/banner2.jpg'
                    },
                    {
                        imgSrc:'../images/banner3.jpg'
                    }
                ];
                
            },300)
        },
        methods:{
            slideChangeEnd(page){
                console.log(page);
            },
            slideMove(page){
                console.log(page);
            },
            slideChangeStart(page){
                console.log(page);
            }
        }
    }
</script>
<style lang="less">
    #vueSwiper{
        .nut-swiper-slide{
            font-size:24px;
            justify-content: center;
            align-items: center;
            display: flex;
        }       
    }
</style>