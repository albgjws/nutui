<template>
  <div>
    <lc-title title="步骤条"></lc-title>
    <category title="正常流程"></category>
    <lc-steps :current="current">
      <lc-step title="已完成" content></lc-step>
      <lc-step title content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="进行中" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="待进行" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="待进行" content="这里是该步骤的描述信息"></lc-step>
    </lc-steps>

    <category title="流程终止"></category>
    <lc-steps :current="current" status="error">
      <lc-step title="已完成" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="已完成" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="进行中" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="待进行" content="这里是该步骤的描述信息"></lc-step>
      <lc-step title="待进行" content="这里是该步骤的描述信息"></lc-step>
    </lc-steps>

  </div>
</template>

<script>
import LcTitle from '_mods/title.vue';
import Category from '_mods/category.vue';
export default {
  components: { LcTitle, Category },
  data() {
    return {
      current: 3
    };
  },
  mounted() {
  },
  methods: {
  }
};
</script>

<style lang="less" scoped>
.nut-steps {
  margin-left: 10px;
}
.next-step {
  text-align: center;
  line-height: 30px;
  color: #ffffff;
  background: #2d8cf0;
  border-radius: 3px;
}
</style>
