<template>
  <div style="background:#f6f6f6">
    <lc-title title="步进器"></lc-title>
    <category title="默认用法"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper @focus="focus" @blur="blur" :value.sync="val1" :max="12" :step="0.1" :decimalPlaces="1" @add="add" @change="change" @reduce="reduce"></lc-stepper>
        </span>
        <span slot="desc">
          value: {{val1}} 
          <!-- <button @click="reduce" class="demo-btn">-</button> <button @click="add" class="demo-btn">+</button>  -->
        </span>
      </lc-cell>
    </div>

    <category title="设置最大最小值"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper :value.sync="val2" :min="5" :max="100"></lc-stepper>
        </span>
      </lc-cell>
    </div>

    <category title="设置加减的步长"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper :value.sync="val3" :step="5"></lc-stepper>
        </span>
      </lc-cell>
    </div>

    <category title="设置只读"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper :value.sync="val4" readonly></lc-stepper>
        </span>
      </lc-cell>
    </div>

    <category title="显示边框"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper :value.sync="val5" :simple="false"></lc-stepper>
        </span>
      </lc-cell>
    </div>

    <category title="关闭动画过渡"></category>
    <div>
      <lc-cell>
        <span slot="title">
          <lc-stepper :value.sync="val6" :transition="false" :simple="false" :max="999"></lc-stepper>
        </span>
      </lc-cell>
    </div>
    
  </div>
</template>

<script>
import LcTitle from '_mods/title.vue';
import Category from '_mods/category.vue';
export default {
  components: { LcTitle, Category },
  data() {
    return {
      val1: 1,
      val2: 12,
      val3: 5,
      val4: 0,
      val5: 0,
      val6: 0
    }
  },
  methods: {
    focus(e, v) {
      console.log('focus,', e, v)
    },
    blur(e, v) {
      console.log('blur,', e, v)
    },
    add(v) {
      console.log('add'+v)
      // this.val1 = Number(this.val1) + 1;
    },
    reduce(v) {
      console.log('reduce'+v)
      // this.val1 = Math.max(Number(this.val1) - 1, 0);
    },
    change(v){
      console.log('change'+v)
    }
  },
};
</script>

<style lang="less" scoped>
.demo-btn{
  border: 1px solid #ddd;
  background: #eee;
  border-radius: 4px;
  outline: none;
  padding: 3px 10px;
  cursor: pointer;
  transition: all .35s;
  &:hover{
    background: #ddd;
  }
}
</style>
